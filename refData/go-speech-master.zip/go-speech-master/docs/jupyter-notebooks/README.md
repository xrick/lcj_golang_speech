You can find here Jupyter notebooks of tests and POC code written in python.

## Usage

Create a `virtualenv` in this directory and install dependencies:
```
virtualenv env
source env/bin/activate
pip install -r requirements.txt
```

Starts Jupyter:
```
jupyter-notebook
```
Go to the URL reported by the previous command and open on of the available notebook.
